/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'ru', {
	fontSize: {
		label: 'Размер',
		voiceLabel: 'Размер шрифта',
		panelTitle: 'Размер шрифта'
	},
	label: 'Шрифт',
	panelTitle: 'Шрифт',
	voiceLabel: 'Шрифт'
} );
