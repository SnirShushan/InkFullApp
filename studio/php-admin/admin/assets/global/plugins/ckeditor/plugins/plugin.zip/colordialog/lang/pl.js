/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'pl', {
	clear: 'Wyczyść',
	highlight: 'Zaznacz',
	options: 'Opcje koloru',
	selected: 'Wybrany',
	title: 'Wybierz kolor'
} );
